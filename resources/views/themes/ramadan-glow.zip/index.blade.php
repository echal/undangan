
<div class="min-h-screen bg-gradient-to-b from-yellow-50 via-yellow-100 to-yellow-200 font-sans">
  <!-- Header / Hero -->
  <header class="text-center py-12 bg-yellow-200">
    <h1 class="text-5xl font-bold text-yellow-900 mb-4">Buka Puasa Bersama</h1>
    <p class="text-lg text-yellow-800">Mari rayakan kebersamaan dan berbagi berkah di bulan suci Ramadan</p>
  </header>

  <!-- Countdown -->
  <section class="text-center py-8">
    <h2 class="text-3xl font-semibold text-yellow-900 mb-2">Countdown Buka Puasa</h2>
    <div id="countdown" class="text-4xl font-bold text-yellow-800">00:12:45:30</div>
  </section>

  <!-- Event Info -->
  <section class="max-w-4xl mx-auto py-12 px-6 bg-yellow-100 rounded-lg shadow-lg mb-12">
    <h3 class="text-2xl font-semibold text-yellow-900 mb-4">Detail Acara</h3>
    <ul class="text-yellow-800 space-y-2">
      <li><strong>Tempat:</strong> Masjid Al-Falah, Jakarta</li>
      <li><strong>Tanggal:</strong> 5 Maret 2026</li>
      <li><strong>Waktu:</strong> 17:45 WIB</li>
    </ul>
  </section>

  <!-- Gallery -->
  <section class="max-w-5xl mx-auto py-12 px-6">
    <h3 class="text-2xl font-semibold text-yellow-900 mb-6 text-center">Galeri Acara</h3>
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
      <img src="{{ asset('themes/ramadan-glow/assets/hero.jpg') }}" alt="Acara 1" class="rounded-lg shadow-md">
      <img src="{{ asset('themes/ramadan-glow/assets/background.png') }}" alt="Acara 2" class="rounded-lg shadow-md">
      <img src="{{ asset('themes/ramadan-glow/assets/hero.jpg') }}" alt="Acara 3" class="rounded-lg shadow-md">
    </div>
  </section>

  <!-- RSVP / Call to Action -->
  <section class="text-center py-12 bg-yellow-200">
    <h3 class="text-2xl font-semibold text-yellow-900 mb-4">Konfirmasi Kehadiran</h3>
    <a href="{{ route('rsvp', ['event' => $event->slug]) }}" 
       class="px-6 py-3 bg-yellow-900 text-yellow-100 rounded-lg shadow hover:bg-yellow-800 transition">RSVP Sekarang</a>
  </section>

  <!-- Footer -->
  <footer class="text-center py-6 text-yellow-800">
    © 2026 Buka Puasa Bersama • All Rights Reserved
  </footer>
</div>
